/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Principal;
import Clases.Procesos;

/**
 *                UNED
 * Curso Programacion Orientada a Objetos
 * II Cuatrimestre 2021
 *        Proyecto 1
 * @author Ronny Gamboa Berrocal
 */
public class Main {
      
    public static void main(String[] args) {
        // TODO code application logic here
        //se crea objeto donde estan los menus iniciales
        Procesos proceso = new Procesos();
               
        //se llama al menu principal
        proceso.menu_inicio();
        System.out.println ("Programa Finalizado");
             
    }
        
  
    //ultima llave del programa no borrar
    }
    
    

