/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;
import java.text.Collator;
import java.util.Scanner;



/**
 *               
 * UNED
 * Curso Programacion Orientada a Objetos
 * II Cuatrimestre 2021
 *           Proyecto 1
 * @author Ronny Gamboa Berrocal
 *
*/
 
//Clase Para llavar el control de una bodega 
//mediante un array de 50 filas y 3 columnas
public class Producto {
    //Se definen las variables a utilizar 
    public String codigo;
    public int cantidad , control_reg_productos;  
    public boolean verifica;
    public String entrada;
    //array para guardar los item de la bodega 
    //se puede registrar un maximo de 50 productos
    String[][] bodega = new String[50][3];
    //se cre objeto leer para capturar desde el teclado
    Scanner leer = new Scanner(System.in);
    //se instancia la clase LimpiarPantalla dentro de la clase Producto
    //se simula la limpieza de pantalla mostrando 50 lineas en blanco
    LimpiarPantalla cls = new LimpiarPantalla();
    
    
    //procedimiento para ingresar un nuevo codigo de producto
    public void agregar_producto(String codigo , String descripcion){
       
       //se utiliza try - cath por si ocurriera una excepcion a la hora de guardar datos
       //los datos vienen filtrados y dificilmente va da error pero originalmente si se ocupo 
       //luego se vario la forma de capturar el entero para el saldo del producto
       try {
            bodega[control_reg_productos][0] = codigo;
            bodega[control_reg_productos][1] = descripcion;
            bodega[control_reg_productos][2] = "0";
            control_reg_productos = control_reg_productos+1;
                  
        } catch(Exception error){
            cls.limpiar();
            System.out.println("Se produjo un error");
            System.out.println("No se puede agregar el nuevo producto");
            System.out.println(" ");
            System.out.println("De enter para continuar");
            //forma de provocar una pausa
            entrada = leer.nextLine();
            cls.limpiar();
        }
    }
    
//procedimiento para verificar existencia de un codigo dentro de la bodega
    public boolean verifica_codigo(String codigo){
       //se utiliza la libreria o clase collator que sirve para comparar 2 variables tipo String
       Collator comparador = Collator.getInstance();
       comparador.setStrength(Collator.PRIMARY);
       boolean existe;
       existe = false;
       String cadena;
             
           for (int linea = 0; linea < 50; linea++){
               cadena = bodega[linea][0];              
               if (comparador.compare(codigo, cadena) == 0)
              {
                  existe = true;
               }
                              
            }
             return existe;
              }   

         
    
    
//procedimiento para iniciar valores de las variables 
    public void iniciar_datos(){
           cantidad = 0;
           control_reg_productos = 0;
           //se inicia el array a utilizar para que sus valores no sean null
           //los valores null dan error en las comparaciones de cadenas
           for (int linea = 0; linea < 50; linea++){
               for (int columna = 0; columna < 3; columna++){
               bodega[linea][columna] = " ";
              }
              }
        
    }
    
//procedimiento para regresar la descricpcion de un codigo
    public String get_descripcion(String codigo){
           //se utiliza la libreria o clase collator que sirve para comparar 2 variables tipo String
           Collator comparador = Collator.getInstance();
           comparador.setStrength(Collator.PRIMARY);
           String descripcion;
           descripcion = "No ingresado";
           
           //se revisan las 50 filas del array a ver si existe el codigo dado y en caso positivo 
           //asignar el nombre del producto  a la variable descripcion
           for (int linea = 0; linea < 50; linea++){
               if (comparador.compare(codigo, bodega[linea][0]) == 0)
              {
                 descripcion =  bodega[linea][1];
               }
            
                                                  }
           //se regresa el valor de la variable descripcion
           return descripcion;
    }   
    
//procedimiento para regresar el saldo en existencia  de un codigo
    public String get_saldo(String codigo){
           //se utiliza la libreria o clase collator que sirve para comparar 2 variables tipo String
           Collator comparador = Collator.getInstance();
           comparador.setStrength(Collator.PRIMARY);
           String saldo;
           saldo = "0";
           
           //se revisan las 50 filas del array a ver si existe el codigo dado y en caso positivo 
           //asignar el valor del saldo a la variable saldo
           for (int linea = 0; linea < 50; linea++){
               if (comparador.compare(codigo, bodega[linea][0]) == 0)
              {
                 saldo =  bodega[linea][2];
               }
            
                                                   }
           //se regresa el valor de la variable saldo
           return saldo;
    }   
    
 

//procedimiento para modificar saldo de producto
    public void modificar_saldo(){
          //declaracion de variables 
           boolean existe , es_numero;
           //se utiliza la libreria o clase collator que sirve para comparar 2 variables tipo String
           Collator comparador = Collator.getInstance();
           comparador.setStrength(Collator.PRIMARY);
           String descripcion , saldo , pausa;
                      
           cls.limpiar();
           System.out.println("Ingrese el codigo a modificar");
           //se lee desde el teclado
           codigo = leer.nextLine();
           
           cls.limpiar();
           System.out.println("Busqueda finalizada");
           System.out.println(" ");
           existe = verifica_codigo(codigo);
           if (existe == true){
               descripcion = get_descripcion(codigo);
               saldo = get_saldo(codigo);
               System.out.println("Bodega #1");
               System.out.println("Codigo: "+codigo);
               System.out.println("Descripcion: "+descripcion);
               System.out.println("Saldo Actual: "+saldo);
               System.out.println("Ingrese el codigo a modificar");
               saldo = leer.nextLine();
               //se inicia bloque para detectar excepcion
               try {
                   //si el dato ingresado no es numerico se produce una excepcion
                   int nuevo_saldo = Integer.valueOf(saldo);
                   //se revisan las 50 filas del array a ver si existe el codigo dado y en caso positivo 
                   //se modifica  el valor del saldo correspondiente a ese codigo
                   for (int linea = 0; linea < 50; linea++){
                       if (comparador.compare(codigo, bodega[linea][0]) == 0)
                           {
                           bodega[linea][2] = saldo;
                           }
                       }
                   cls.limpiar();
                   System.out.println("Se Actualizado el saldo del producto ");
                                    
                   
               }catch(Exception error){
                        cls.limpiar();
                        System.out.println("Datos ingresado incorrectos");
                        System.out.println("Solo se pueden ingresar datos numericos");
                        System.out.println("No se modifica el saldo del producto");
                                      }
               
           }else{
                System.out.println("Codigo "+codigo+" no ingresado en esta Bodega");
                System.out.println("No se puede modificar el saldo");
           }
                            
                System.out.println (" ");
                System.out.println ("De enter para continuar");
                pausa = leer.nextLine();
           }    
    
    
//Ultima llave no borrar
}
