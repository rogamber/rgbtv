/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;

/**
 *
 * @author Ronny Gamboa Berrocal
 */
public class LimpiarPantalla {
       
    
    public void limpiar(){
        //se ingresan 50 lineas en blanco 
        //para simular la limpieza de la pantalla
        for(int i = 0; i <= 50; i = i + 1)
      {       
            System.out.println(" ");
      }
    
    
}
}