/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Clases;
import java.util.Scanner;
import java.text.Collator;


/**
 *UNED
 * Curso Programacion Orientada a Objetos
 * II Cuatrimestre 2021
 *           Proyecto 1
 * @author Ronny Gamboa Berrocal
 */
public class Procesos {
    //se crea objeto leer para entrada desde el teclado
    Scanner leer = new Scanner(System.in);
    //se instancia la clase LimpiarPantalla dentro de la clase Procesos
    LimpiarPantalla cls = new LimpiarPantalla();
    //se crean los objetos de las 3 bodegas
    Producto Bodega1 = new Producto();
    Producto Bodega2 = new Producto();
    Producto Bodega3 = new Producto();
    String Eleccion , seguir;       
   
    public void menu_inicio(){
       //se inician los datos(arrays) y varibles de los 3 objetos de Bodega
       //los arrays no iniciados dan error de null al comparar con varibles String 
       Bodega1.iniciar_datos();
       Bodega2.iniciar_datos();
       Bodega3.iniciar_datos();
       //se declara variable booleana para mantener el bucle del menu principal
       boolean salir;
       salir = false;
        
         //se crea el menu principal
        while (salir == false) {  
                 System.out.println ("Menu Principal");
                 System.out.println (" ");
                 System.out.println ("(1) Manejo Bodega 1");
                 System.out.println ("(2) Manejo Bodega 2");
                 System.out.println ("(3) Manejo Bodega 3");
                 System.out.println ("(4) Buscar codigo");
                 System.out.println ("(5) Salir");
        
                 System.out.println (" ");
                 System.out.println ("Ingrese el No de Eleccion");
                 Eleccion = leer.nextLine();
                 
                 switch (Eleccion) {
                                      
                       case "1":
                           cls.limpiar();
                           //se llama al menu de la Bodega 1
                           menu_manejo_bodega1();
                           cls.limpiar();
                           break;
                           
                       case "2":
                           cls.limpiar();
                           //se llama al menu de la Bodega 2
                           menu_manejo_bodega2();
                           cls.limpiar();
                           break;
                           
                       case "3":
                           cls.limpiar();
                           //se llama al menu de la Bodega 3
                           menu_manejo_bodega3();
                           cls.limpiar();
                           break;
                           
                       case "4":
                           cls.limpiar();
                           //se llama al medoto para ver un producto por su codigo
                           ver_codigo();
                           cls.limpiar();
                           break;
                           
                         case "5":
                           //si se da la opcion 5 se sale del bucle del menu principal
                           //y se finaliza el programa
                           salir = true;
                           cls.limpiar();
                           break;
                       
                       default:
                           cls.limpiar();
                           System.out.println ("   Opcion incorrecta");
                           System.out.println ("de enter para continuar");
                           seguir = leer.nextLine();
                           cls.limpiar();
                           break;

 

 }

        }  
    
}
 
//Procedimiento o metodo para crear el menu de la Bodega 1
public void menu_manejo_bodega1(){
        
        String Eleccion , codigo , descripcion , opcion;
        boolean salir , existe1 , existe2 , existe3 ;
        salir = false;
        descripcion = " ";
        //se utiliza la libreria o clase collator que sirve para comparar 2 variables tipo String
        Collator comparador = Collator.getInstance();
        comparador.setStrength(Collator.PRIMARY);
       
        //inicio del bucle del menu
         while (salir == false) {  
                 System.out.println ("Mantenimiento de Bodega #1");
                 System.out.println (" ");
                 System.out.println ("(1) Agregar nuevo Producto");
                 System.out.println ("(2) Modificar saldo de un Producto");
                 System.out.println ("(3) Salir");
                 System.out.println (" ");
                 System.out.println ("Ingrese el No de Eleccion");
                 Eleccion = leer.nextLine();
                 
                 switch (Eleccion) {
                       case "1":
                           cls.limpiar();
                           //se le solicta ingresar el codigo que puede ser alfa-numerico (letras y numeros)
                           System.out.println("Ingrese el nuevo codigo");
                           //se captura el codigo desde el teclado
                           codigo = leer.nextLine();
                           //se verifica si el codigo existe en bodega 1
                           existe1 = Bodega1.verifica_codigo(codigo);
                           if (existe1==true){
                               descripcion = Bodega1.get_descripcion(codigo);
                               cls.limpiar();
                               //si el codigo ya existe se indica en pantalla
                               System.out.println("Codigo ya ingresado en esta bodega");
                               System.out.println("con la descripcion: "+descripcion);
                               System.out.println(" ");
                               System.out.println("De ENTER para continuar");
                               opcion = leer.nextLine();
                           }else{
                                //se verifica si el codigo existe en bodega 2
                                existe2 = Bodega2.verifica_codigo(codigo);
                                if (existe2==true){
                                    descripcion = Bodega2.get_descripcion(codigo);
                                                  }
                                //se verifica si el codigo existe en bodega 3
                                existe3 = Bodega3.verifica_codigo(codigo);
                                if (existe3==true){
                                    descripcion = Bodega3.get_descripcion(codigo);
                                                  }
                                if (existe2==true||existe3==true){
                                   cls.limpiar();
                                   //si codigo existe en bodega 2 o 3 se indica en pantalla
                                   System.out.println("Codigo ya ingresado en otra bodega");
                                   System.out.println("con la descripcion: "+descripcion);
                                   System.out.println(" ");
                                   //se le consulta al usuario si desea usar el codigo ya ingresado
                                   System.out.println("Desea agregarlo? s/n");
                                   opcion = leer.nextLine();
                                   //si el usurio contesta s o S se agrega el codigo a la bodega 1
                                   if (comparador.compare(opcion , "s") == 0||comparador.compare(opcion , "S") == 0){
                                       cls.limpiar();
                                       Bodega1.agregar_producto(codigo , descripcion);   
                                       System.out.println(" ");
                                       System.out.println("Nuevo producto ingresado");
                                       System.out.println("De ENTER para continuar");
                                       opcion = leer.nextLine();
                                       cls.limpiar();
                                    }else{
                                         cls.limpiar();
                                         System.out.println("NO de agrego el producto");
                                         System.out.println("De ENTER para continuar");
                                         opcion = leer.nextLine();
                                         cls.limpiar();
                                        }
                           //en caso de que el codigo no habia sido ingresado se solicta la nueva descripcion del producto
                           }else{ 
                                   System.out.println("Ingrese la descripcion del nuevo producto");
                                   descripcion = leer.nextLine();
                                   Bodega1.agregar_producto(codigo , descripcion); 
                                   cls.limpiar();
                                   System.out.println(" ");
                                   System.out.println("Nuevo producto ingresado");
                                   System.out.println("De ENTER para continuar");
                                   opcion = leer.nextLine();
                                   cls.limpiar();
                                   }
                           }
                           cls.limpiar();
                           break;
                           
                       case "2":
                           cls.limpiar();
                           Bodega1.modificar_saldo();
                           cls.limpiar();
                           break;
                           
                       case "3":
                           salir = true;
                           cls.limpiar();
                           break;
                       
                       default:
                           cls.limpiar();
                           System.out.println ("   Opcion incorrecta");
                           System.out.println ("de enter para continuar");
                           seguir = leer.nextLine();
                           cls.limpiar();
                           break;

 

 }

        }                
    }

//Procedimiento o metodo para crear el menu de la Bodega 2
public void menu_manejo_bodega2(){
        
        String Eleccion , codigo , descripcion , opcion;
        boolean salir , existe1 , existe2 , existe3 ;
        salir = false;
        descripcion = " ";
        //se utiliza la libreria o clase collator que sirve para comparar 2 variables tipo String
        Collator comparador = Collator.getInstance();
        comparador.setStrength(Collator.PRIMARY);
       
        //inicio del bucle del menu
         while (salir == false) {  
                 System.out.println ("Mantenimiento de Bodega #2");
                 System.out.println (" ");
                 System.out.println ("(1) Agregar nuevo Producto");
                 System.out.println ("(2) Modificar saldo de un Producto");
                 System.out.println ("(3) Salir");
                 System.out.println (" ");
                 System.out.println ("Ingrese el No de Eleccion");
                 Eleccion = leer.nextLine();
                 
                 switch (Eleccion) {
                       case "1":
                           cls.limpiar();
                           //se le solicta ingresar el codigo que puede ser alfa-numerico (letras y numeros)
                           System.out.println("Ingrese el nuevo codigo");
                           //se captura el codigo desde el teclado
                           codigo = leer.nextLine();
                           //se verifica si el codigo existe en bodega 2
                           existe2 = Bodega2.verifica_codigo(codigo);
                           if (existe2==true){
                               descripcion = Bodega2.get_descripcion(codigo);
                               cls.limpiar();
                               //si el codigo ya existe se indica en pantalla
                               System.out.println("Codigo ya ingresado en esta bodega");
                               System.out.println("con la descripcion: "+descripcion);
                               System.out.println(" ");
                               System.out.println("De ENTER para continuar");
                               opcion = leer.nextLine();
                           }else{
                                //se verifica si el codigo existe en bodega 1
                                existe1 = Bodega1.verifica_codigo(codigo);
                                if (existe1==true){
                                    descripcion = Bodega1.get_descripcion(codigo);
                                                  }
                                //se verifica si el codigo existe en bodega 3
                                existe3 = Bodega3.verifica_codigo(codigo);
                                if (existe3==true){
                                    descripcion = Bodega3.get_descripcion(codigo);
                                                  }
                                if (existe1==true||existe3==true){
                                   cls.limpiar(); 
                                   //si codigo existe en bodega 1 o 3 se indica en pantalla
                                   System.out.println("Codigo ya ingresado en otra bodega");
                                   System.out.println("con la descripcion: "+descripcion);
                                   System.out.println(" ");
                                   //se le consulta al usuario si desea usar el codigo ya ingresado
                                   System.out.println("Desea agregarlo? s/n");
                                   opcion = leer.nextLine();
                                   //si el usuario contesta s o S se agrega el codigo a la bodega 2
                                   if (comparador.compare(opcion , "s") == 0||comparador.compare(opcion , "S") == 0){
                                       cls.limpiar();
                                       Bodega2.agregar_producto(codigo , descripcion);   
                                       System.out.println(" ");
                                       System.out.println("Nuevo producto ingresado");
                                       System.out.println("De ENTER para continuar");
                                       opcion = leer.nextLine();
                                       cls.limpiar();
                                    }else{
                                         cls.limpiar();
                                         System.out.println("NO se agrego el producto");
                                         System.out.println("De ENTER para continuar");
                                         opcion = leer.nextLine();
                                         cls.limpiar();
                                        }
                            //en caso de que el codigo no habia sido ingresado se solicita la nueva descripcion del producto
                           }else{ 
                                   System.out.println("Ingrese la descripcion del nuevo producto");
                                   descripcion = leer.nextLine();
                                   Bodega2.agregar_producto(codigo , descripcion); 
                                   cls.limpiar();
                                   System.out.println(" ");
                                   System.out.println("Nuevo producto ingresado");
                                   System.out.println("De ENTER para continuar");
                                   opcion = leer.nextLine();
                                   cls.limpiar();
                                   }
                           }
                           cls.limpiar();
                           break;
                           
                       case "2":
                           cls.limpiar();
                           Bodega2.modificar_saldo();
                           cls.limpiar();
                           break;
                           
                       case "3":
                           salir = true;
                           cls.limpiar();
                           break;
                       
                       default:
                           cls.limpiar();
                           System.out.println ("   Opcion incorrecta");
                           System.out.println ("de enter para continuar");
                           seguir = leer.nextLine();
                           cls.limpiar();
                           break;

 

 }

        }                
    }
 
//Procedimiento o metodo para crear el menu de la Bodega 3
public void menu_manejo_bodega3(){
        
        //declaracion de variables
        String Eleccion , codigo , descripcion , opcion;
        boolean salir , existe1 , existe2 , existe3 ;
        salir = false;
        descripcion = " ";
        //se utiliza la libreria o clase collator que sirve para comparar 2 variables tipo String
        Collator comparador = Collator.getInstance();
        comparador.setStrength(Collator.PRIMARY);
       
        //inicio del bucle del menu
         while (salir == false) {  
                 System.out.println ("Mantenimiento de Bodega #3");
                 System.out.println (" ");
                 System.out.println ("(1) Agregar nuevo Producto");
                 System.out.println ("(2) Modificar saldo de un Producto");
                 System.out.println ("(3) Salir");
                 System.out.println (" ");
                 System.out.println ("Ingrese el No de Eleccion");
                 Eleccion = leer.nextLine();
                 
                 switch (Eleccion) {
                       case "1":
                           cls.limpiar();
                           //se le solicta ingresar el codigo que puede ser alfa-numerico (letras y numeros)
                           System.out.println("Ingrese el nuevo codigo");
                           //se captura el codigo desde el teclado
                           codigo = leer.nextLine();
                           //se verifica si el codigo existe en bodega 3
                           existe3 = Bodega3.verifica_codigo(codigo);
                           if (existe3==true){
                               descripcion = Bodega3.get_descripcion(codigo);
                               cls.limpiar();
                               //si el codigo ya existe se indica en pantalla
                               System.out.println("Codigo ya ingresado en esta bodega");
                               System.out.println("con la descripcion: "+descripcion);
                               System.out.println(" ");
                               System.out.println("De ENTER para continuar");
                               opcion = leer.nextLine();
                           }else{
                                //se verifica si el codigo existe en bodega 1
                                existe1 = Bodega1.verifica_codigo(codigo);
                                if (existe1==true){
                                    descripcion = Bodega1.get_descripcion(codigo);
                                                  }
                                //se verifica si el codigo existe en bodega 2
                                existe2 = Bodega2.verifica_codigo(codigo);
                                if (existe2==true){
                                    descripcion = Bodega2.get_descripcion(codigo);
                                                  }
                                if (existe1==true||existe2==true){
                                   cls.limpiar(); 
                                   //si codigo existe en bodega 1 o 2 se indica en pantalla
                                   System.out.println("Codigo ya ingresado en otra bodega");
                                   System.out.println("con la descripcion: "+descripcion);
                                   System.out.println(" ");
                                    //se le consulta al usuario si desea usar el codigo ya ingresado
                                   System.out.println("Desea agregarlo? s/n");
                                   opcion = leer.nextLine();
                                   //si el usuario contesta s o S se agrega el codigo a la bodega 3
                                   if (comparador.compare(opcion , "s") == 0||comparador.compare(opcion , "S") == 0){
                                       cls.limpiar();
                                       Bodega3.agregar_producto(codigo , descripcion);   
                                       System.out.println(" ");
                                       System.out.println("Nuevo producto ingresado");
                                       System.out.println("De ENTER para continuar");
                                       opcion = leer.nextLine();
                                       cls.limpiar();
                                    }else{
                                         cls.limpiar();
                                         System.out.println("NO se agrego el producto");
                                         System.out.println("De ENTER para continuar");
                                         opcion = leer.nextLine();
                                         cls.limpiar();
                                        }
                           //en caso de que el codigo no habia sido ingresado se solicita la nueva descripcion del producto
                           }else{ 
                                   System.out.println("Ingrese la descripcion del nuevo producto");
                                   descripcion = leer.nextLine();
                                   Bodega3.agregar_producto(codigo , descripcion); 
                                   cls.limpiar();
                                   System.out.println(" ");
                                   System.out.println("Nuevo producto ingresado");
                                   System.out.println("De ENTER para continuar");
                                   opcion = leer.nextLine();
                                   cls.limpiar();
                                   }
                           }
                           cls.limpiar();
                           break;
                           
                       case "2":
                           cls.limpiar();
                           Bodega3.modificar_saldo();
                           cls.limpiar();
                           break;
                           
                       case "3":
                           salir = true;
                           cls.limpiar();
                           break;
                       
                       default:
                           cls.limpiar();
                           System.out.println ("   Opcion incorrecta");
                           System.out.println ("de enter para continuar");
                           seguir = leer.nextLine();
                           cls.limpiar();
                           break;

 

 }

        }                
    }


//procedimiento para ver existencia de un codigo en las Bodegas
    public void ver_codigo(){
           String codigo,pausa;
           boolean existe;
           Collator comparador = Collator.getInstance();
           comparador.setStrength(Collator.PRIMARY);
           String descripcion , saldo;
                      
           cls.limpiar();
           System.out.println("Ingrese el codigo a buscar");
           //se lle desde el teclado el codigo a verificar
           codigo = leer.nextLine();
           
           cls.limpiar();
           System.out.println("Resultados de la busqueda");
           System.out.println(" ");
           //se verifica en bodega 1 si el codigo ingresado existe
           existe = Bodega1.verifica_codigo(codigo);
           if (existe == true){
               //si el codigo ingresado exsite en bodega uno se extraen los datos y se muestran en panatalla
               descripcion = Bodega1.get_descripcion(codigo);
               saldo = Bodega1.get_saldo(codigo);
               System.out.println("Bodega #1 "+"Codigo: "+codigo+" "+"Descripcion: "+descripcion+" "+"Saldo: "+saldo);
           }else{
                System.out.println("Codigo "+codigo+" no ingresado en Bodega #1");
           }
            
           //se verifica en bodega 2 si el codigo ingresado existe
           existe = Bodega2.verifica_codigo(codigo);
           if (existe == true){
               //si el codigo ingresado exsite en bodega uno se extraen los datos y se muestran en panatalla
               descripcion = Bodega2.get_descripcion(codigo);
               saldo = Bodega2.get_saldo(codigo);
               System.out.println("Bodega #2 "+"Codigo: "+codigo+" "+"Descripcion: "+descripcion+" "+"Saldo: "+saldo);
           }else{
                System.out.println("Codigo "+codigo+" no ingresado en Bodega #2");
           }
           //se verifica en bodega 3 si el codigo ingresado existe
           existe = Bodega3.verifica_codigo(codigo);
           if (existe == true){
               //si el codigo ingresado exsite en bodega uno se extraen los datos y se muestran en panatalla
               descripcion = Bodega3.get_descripcion(codigo);
               saldo = Bodega3.get_saldo(codigo);
               System.out.println("Bodega #3 "+"Codigo: "+codigo+" "+"Descripcion: "+descripcion+" "+"Saldo: "+saldo);
           }else{
                System.out.println("Codigo "+codigo+" no ingresado en Bodega #3");
           }
           
                System.out.println (" ");
                System.out.println ("De enter para continuar");
                pausa = leer.nextLine();
           }
            
                      
           
      
    
 //ultima llave no borrar 
}
    

    
